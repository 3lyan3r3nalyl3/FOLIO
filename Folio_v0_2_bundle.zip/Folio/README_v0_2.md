# FOLIO v0.2 — Memory / Breath / Protection

Folio v0.2 grows directly from v0.1. The original four-clock rhythm ecology,
internal synthesis, optional seed-file organism and literal audio SAVE remain
intact.

The new version adds three things without turning Folio into a sequencer or DAW:

## 1. MEMORY now remembers actual rhythmic decisions

Each of Folio's four clocks has a small private memory of recent "speak / do not
speak" decisions.

At low MEMORY, events remain loose and probabilistic.

At higher MEMORY, a clock increasingly refers back to a short phrase from its
own recent past. The four clocks use different memory lengths, so the result is
not a conventional one-bar loop. Motifs can overlap, recur, drift and misremember
themselves.

DISORDER increases memory slips. MEMORY resists them.

## 2. SPACE

SPACE is a new eighth knob.

It is not a volume control. After sufficiently active passages, SPACE can make
the event ecology deliberately stop speaking for a musically timed interval.

Low SPACE:
    dense continuity

Medium SPACE:
    breathing / holes / punctuation

High SPACE:
    larger absences and sudden returns

The aim is to make silence an active compositional event.

## 3. Selective protection

### RHYTHM · LOCKED

- clock timing stops drifting
- remembered motifs become highly stable
- MUTATE and REGENERATE protect:
  - density
  - disorder
  - memory
  - space
  - BPM
  - clock ratios

This is the button to use when Folio discovers a rhythm whose skeleton you want
to keep while exploring other sound worlds.

### TIMBRE · LOCKED

MUTATE and REGENERATE preserve:
- timbre
- fragmentation
- internal synthesis-family balance

Runtime sound events still breathe and vary: this protects the *ecology*, not
a frozen sample playback.

Both locks may be active together.

## STORE STATE / RECALL

STORE STATE writes the current Folio genome to:

    ~/Folio_States/

as:

    Folio_YYYYMMDD_HHMMSS.folio.json

This is deliberately separate from SAVE.

- SAVE = the actual recent audio you heard
- STORE STATE = the organism/settings that produced it

RECALL loads one of those state files.

Seed audio itself is not embedded into the state file. The state records the
seed name only; load the seed audio separately when needed.

## SAVE remains literal

SAVE still writes the most recent 16 seconds from Folio's rolling audio memory
as 24-bit WAV:

    ~/Folio_Captures/

There is no re-render and no second random pass. The file contains the sound
that actually came out of Folio.

## Install / run

Use the same venv that already runs Folio v0.1:

```bash
cd ~/src/Folio
source .venv/bin/activate
python folio_v0_2.py
```

There are no new Python dependencies in v0.2.

## Suggested first experiment

1. Start with MEMORY around 0.65.
2. Set SPACE around 0.25–0.40.
3. Let Folio run long enough for motifs to form.
4. When a compelling rhythmic skeleton appears, press RHYTHM · LOOSE so it
   becomes RHYTHM · LOCKED.
5. Press MUTATE repeatedly and listen to the sound ecology change around the
   protected rhythm.
6. Use TIMBRE LOCK in the opposite way: protect a particularly good sound
   ecology while letting the rhythm regenerate.
7. SAVE whenever the actual performance becomes worth preserving.

Folio remains an instrument, not a miniature DAW.
