#!/usr/bin/env bash
set -euo pipefail

# Folio v0.2 experimental standalone Linux build.
#
# Activate Folio's venv, then install Nuitka once:
#   python -m pip install nuitka ordered-set zstandard
#
# Build:
#   ./build_folio_v0_2.sh

python -m nuitka \
  --standalone \
  --onefile \
  --enable-plugin=tk-inter \
  --include-package=sounddevice \
  --include-package=soundfile \
  --output-filename=Folio \
  folio_v0_2.py

echo
echo "Folio binary build finished."
