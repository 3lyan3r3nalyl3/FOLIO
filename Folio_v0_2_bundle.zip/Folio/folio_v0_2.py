#!/usr/bin/env python3
"""
FOLIO v0.2
A compact generative rhythm organism / sampler for Linux.

Core ideas:
- No seed file required: Folio synthesizes its own percussion.
- Optional seed audio: transient-ish fragments become extra sound material.
- Four interacting clocks rather than a conventional step sequencer.
- MEMORY now forms short recurring rhythmic motifs rather than only biasing density.
- DISORDER destabilizes clock timing.
- MUTATION changes event timbre without destroying the current organism.
- REGENERATE creates a new organism.
- MUTATE creates a related descendant.
- SPACE creates musically timed gaps after dense activity.
- RHYTHM LOCK can stabilize a discovered rhythmic organism.
- TIMBRE LOCK protects the current sound ecology while rhythm changes.
- STORE/RECALL preserve Folio genomes as small .folio.json state files.
- SAVE writes the recent audio you actually heard to WAV, with no re-render.

Dependencies:
    python3 -m pip install numpy sounddevice soundfile

On Debian/Ubuntu you may also need:
    sudo apt install python3-tk libportaudio2 libsndfile1

Run:
    python3 folio_v0_1.py
"""

from __future__ import annotations

import math
import os
import json
import queue
import random
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

try:
    import numpy as np
    import sounddevice as sd
    import soundfile as sf
except Exception as exc:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(
        "Folio — missing dependency",
        "Folio needs numpy, sounddevice and soundfile.\n\n"
        "Install with:\n"
        "python3 -m pip install numpy sounddevice soundfile\n\n"
        f"Original error:\n{exc}"
    )
    raise SystemExit(1)

APP_NAME = "FOLIO"
VERSION = "0.2"
SR = 48_000
BLOCK = 512
CHANNELS = 2
HISTORY_SECONDS = 16.0
MASTER_HEADROOM = 0.72

PANEL = "#151515"
PANEL_2 = "#1d1d1d"
TEXT = "#e8e1d2"
MUTED = "#8d887f"
EDGE = "#353535"
ACCENT = "#d4c27f"
HOT = "#f2d791"
DARK = "#090909"

FAMILIES = ("pulse", "noise", "resonator", "fm", "particle")


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def softclip(x):
    return np.tanh(x)


def equal_power_pan(pan):
    pan = clamp(pan, -1.0, 1.0)
    a = (pan + 1.0) * math.pi / 4.0
    return math.cos(a), math.sin(a)


def resample_linear(x, src_sr, dst_sr):
    if src_sr == dst_sr or len(x) < 2:
        return np.asarray(x, dtype=np.float32)
    duration = len(x) / float(src_sr)
    new_len = max(2, int(round(duration * dst_sr)))
    old_pos = np.linspace(0.0, 1.0, len(x), endpoint=False)
    new_pos = np.linspace(0.0, 1.0, new_len, endpoint=False)
    return np.interp(new_pos, old_pos, x).astype(np.float32)


@dataclass
class Genome:
    density: float = 0.58
    disorder: float = 0.38
    memory: float = 0.52
    space: float = 0.28
    mutation: float = 0.34
    fragment: float = 0.35
    timbre: float = 0.50
    bpm: float = 116.0
    ratios: list[float] = field(default_factory=lambda: [1.0, 0.75, 1.333, 1.875])
    family_bias: list[float] = field(default_factory=lambda: [0.22, 0.22, 0.20, 0.18, 0.18])

    def copy(self):
        return Genome(
            density=self.density,
            disorder=self.disorder,
            memory=self.memory,
            space=self.space,
            mutation=self.mutation,
            fragment=self.fragment,
            timbre=self.timbre,
            bpm=self.bpm,
            ratios=list(self.ratios),
            family_bias=list(self.family_bias),
        )


@dataclass
class Voice:
    audio: np.ndarray
    pos: int = 0
    delay: int = 0


class FolioEngine:
    def __init__(self):
        self.lock = threading.RLock()
        self.running = False
        self.stream = None

        self.genome = Genome()
        self.rng = np.random.default_rng()
        self.py_rng = random.Random()

        self.sample_clock = 0
        self.next_triggers = np.zeros(4, dtype=np.int64)
        self.voices: list[Voice] = []

        self.last_family = 0
        self.family_memory = deque(maxlen=12)
        self.interval_memory = deque(maxlen=16)

        # v0.2: each clock remembers its recent yes/no event decisions.
        # High MEMORY allows these short phrases to become recognisable motifs.
        self.clock_memory = [deque(maxlen=32) for _ in range(4)]
        self.rest_until_sample = 0

        # Selective protection: these locks do not stop Folio; they protect
        # aspects of the organism during mutation/regeneration and, for rhythm,
        # make remembered event patterns much more deterministic.
        self.rhythm_lock = False
        self.timbre_lock = False

        history_blocks = int(math.ceil(HISTORY_SECONDS * SR / BLOCK)) + 4
        self.history = deque(maxlen=history_blocks)
        self.scope = np.zeros((BLOCK, 2), dtype=np.float32)
        self.scope_lock = threading.Lock()

        self.seed_path: Path | None = None
        self.seed_fragments: list[np.ndarray] = []
        self.seed_enabled = False

        self.event_queue = queue.SimpleQueue()

        self.regenerate(initial=True)

    # ---------- genome ----------
    def regenerate(self, initial=False):
        with self.lock:
            old = self.genome.copy()
            g = old.copy()

            if not initial:
                if not self.rhythm_lock:
                    g.density = self.rng.uniform(0.35, 0.78)
                    g.disorder = self.rng.uniform(0.18, 0.72)
                    g.memory = self.rng.uniform(0.25, 0.84)
                    g.space = self.rng.uniform(0.08, 0.72)
                    g.bpm = self.rng.uniform(78.0, 148.0)

                if not self.timbre_lock:
                    g.fragment = self.rng.uniform(0.10, 0.70)
                    g.timbre = self.rng.uniform(0.20, 0.82)
                    g.mutation = self.rng.uniform(0.15, 0.65)

            if initial or not self.rhythm_lock:
                base_choices = np.array(
                    [0.5, 2/3, 0.75, 0.8, 1.0, 1.125, 1.25, 4/3, 1.5, 1.75, 1.875, 2.0],
                    dtype=float
                )
                ratios = [1.0]
                for _ in range(3):
                    r = float(self.rng.choice(base_choices))
                    r *= float(self.rng.uniform(0.985, 1.015))
                    ratios.append(r)
                g.ratios = ratios

            if initial or not self.timbre_lock:
                raw = self.rng.uniform(0.5, 1.5, len(FAMILIES))
                raw /= raw.sum()
                g.family_bias = raw.tolist()

            self.genome = g
            self._reset_clock_schedule()
            self.rest_until_sample = 0

            # A rhythm lock deliberately retains its motif memory.
            if not self.rhythm_lock:
                for mem in self.clock_memory:
                    mem.clear()
                self.interval_memory.clear()

            if not self.timbre_lock:
                self.family_memory.clear()

    def mutate_genome(self):
        """Create a nearby descendant while respecting selective locks."""
        with self.lock:
            g = self.genome.copy()
            strength = 0.045 + 0.20 * g.mutation

            if not self.rhythm_lock:
                for name in ("density", "disorder", "memory", "space"):
                    value = getattr(g, name)
                    value += float(self.rng.normal(0.0, strength))
                    setattr(g, name, clamp(value))

                g.bpm = float(np.clip(
                    g.bpm + self.rng.normal(0.0, 3.0 + 10.0 * g.mutation),
                    45.0, 220.0
                ))

                ratios = []
                for r in g.ratios:
                    if self.rng.random() < 0.65:
                        r *= float(self.rng.uniform(
                            1.0 - strength * 0.25,
                            1.0 + strength * 0.25
                        ))
                    ratios.append(float(np.clip(r, 0.35, 3.0)))
                ratios[0] = 1.0
                g.ratios = ratios

            if not self.timbre_lock:
                for name in ("fragment", "timbre"):
                    value = getattr(g, name)
                    value += float(self.rng.normal(0.0, strength))
                    setattr(g, name, clamp(value))

                b = np.asarray(g.family_bias, dtype=float)
                b += self.rng.normal(0.0, strength * 0.15, len(b))
                b = np.clip(b, 0.02, None)
                b /= b.sum()
                g.family_bias = b.tolist()

            self.genome = g
            self._reset_clock_schedule()
            self.rest_until_sample = 0

    def set_param(self, name, value):
        with self.lock:
            if name == "bpm":
                self.genome.bpm = float(np.clip(value, 45.0, 220.0))
                self._reset_clock_schedule()
            elif hasattr(self.genome, name):
                setattr(self.genome, name, clamp(float(value)))

    def snapshot(self):
        with self.lock:
            return self.genome.copy()

    def toggle_rhythm_lock(self):
        with self.lock:
            self.rhythm_lock = not self.rhythm_lock
            return self.rhythm_lock

    def toggle_timbre_lock(self):
        with self.lock:
            self.timbre_lock = not self.timbre_lock
            return self.timbre_lock

    def state_dict(self):
        with self.lock:
            g = self.genome.copy()
            return {
                "format": "Folio state",
                "version": VERSION,
                "genome": {
                    "density": g.density,
                    "disorder": g.disorder,
                    "memory": g.memory,
                    "space": g.space,
                    "mutation": g.mutation,
                    "fragment": g.fragment,
                    "timbre": g.timbre,
                    "bpm": g.bpm,
                    "ratios": list(g.ratios),
                    "family_bias": list(g.family_bias),
                },
                "rhythm_lock": self.rhythm_lock,
                "timbre_lock": self.timbre_lock,
                "seed_name": self.seed_path.name if self.seed_path else None,
            }

    def store_state(self, out_dir=None):
        if out_dir is None:
            out_dir = Path.home() / "Folio_States"
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = out_dir / f"Folio_{stamp}.folio.json"
        path.write_text(json.dumps(self.state_dict(), indent=2), encoding="utf-8")
        return path

    def recall_state(self, path):
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        gd = data.get("genome", {})

        with self.lock:
            g = self.genome.copy()
            for name in ("density", "disorder", "memory", "space",
                         "mutation", "fragment", "timbre"):
                if name in gd:
                    setattr(g, name, clamp(float(gd[name])))

            if "bpm" in gd:
                g.bpm = float(np.clip(float(gd["bpm"]), 45.0, 220.0))

            if "ratios" in gd and len(gd["ratios"]) == 4:
                g.ratios = [float(np.clip(float(x), 0.35, 3.0))
                            for x in gd["ratios"]]
                g.ratios[0] = 1.0

            if "family_bias" in gd and len(gd["family_bias"]) == len(FAMILIES):
                b = np.asarray(gd["family_bias"], dtype=float)
                b = np.clip(b, 0.001, None)
                b /= b.sum()
                g.family_bias = b.tolist()

            self.genome = g
            self.rhythm_lock = bool(data.get("rhythm_lock", False))
            self.timbre_lock = bool(data.get("timbre_lock", False))
            self.rest_until_sample = 0
            self._reset_clock_schedule()
            for mem in self.clock_memory:
                mem.clear()
            self.interval_memory.clear()
            self.family_memory.clear()

        return data

    # ---------- audio ----------
    def _reset_clock_schedule(self):
        now = self.sample_clock
        g = self.genome
        beat = 60.0 / max(30.0, g.bpm)
        for i, ratio in enumerate(g.ratios):
            period = beat * ratio
            phase = self.rng.uniform(0.05, max(0.06, period))
            self.next_triggers[i] = now + int(phase * SR)

    def start(self):
        if self.running:
            return
        try:
            self.stream = sd.OutputStream(
                samplerate=SR,
                blocksize=BLOCK,
                channels=CHANNELS,
                dtype="float32",
                latency="low",
                callback=self._callback,
            )
            self.stream.start()
            self.running = True
        except Exception as exc:
            self.running = False
            if self.stream:
                try:
                    self.stream.close()
                except Exception:
                    pass
                self.stream = None
            raise RuntimeError(str(exc))

    def stop(self):
        self.running = False
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None

    def _schedule_next(self, clock_index, trigger_sample, g):
        beat = 60.0 / max(30.0, g.bpm)
        base_period = beat * g.ratios[clock_index]

        # Small probabilistic tempo fracture. MEMORY opposes DISORDER.
        # RHYTHM LOCK removes timing drift while retaining the interacting ratios.
        if self.rhythm_lock:
            disorder_amount = 0.0
        else:
            disorder_amount = g.disorder * (1.05 - 0.70 * g.memory)

        jitter = float(self.rng.normal(0.0, base_period * 0.13 * disorder_amount))

        # Occasional rational displacement gives larger structural tears.
        if (not self.rhythm_lock) and self.rng.random() < 0.035 * g.disorder:
            jump = float(self.rng.choice([0.5, 2/3, 1.5, 2.0]))
            base_period *= jump

        period = float(np.clip(base_period + jitter, 0.018, 4.0))
        self.next_triggers[clock_index] = trigger_sample + max(1, int(period * SR))

    def _should_emit(self, clock_index, g, trigger_sample):
        """Decide whether a clock event speaks.

        v0.2 gives MEMORY a literal short-term rhythmic memory.  Each clock
        remembers a short string of yes/no decisions.  At higher MEMORY values
        Folio increasingly refers back to those earlier decisions, producing
        motifs that can recur and then slip away.

        SPACE creates brief rests after dense activity.  It does not lower the
        volume; it changes the event ecology itself.
        """
        history = self.clock_memory[clock_index]

        if trigger_sample < self.rest_until_sample:
            history.append(0)
            self.interval_memory.append(0)
            return False

        base = 0.18 + 0.68 * g.density
        clock_weight = (1.0, 0.82, 0.72, 0.64)[clock_index]
        p = base * clock_weight

        recent = sum(self.interval_memory)
        activity = 0.0
        if len(self.interval_memory) >= 6:
            activity = recent / len(self.interval_memory)
            target = 0.20 + 0.70 * g.density
            correction = (target - activity) * (0.25 + 0.55 * g.memory)
            p += correction

        # SPACE: after an active passage, Folio may deliberately leave a gap.
        if len(self.interval_memory) >= 10 and activity > (0.52 + 0.20 * g.density):
            chance = 0.010 + 0.070 * g.space
            if self.rng.random() < chance:
                beat = 60.0 / max(30.0, g.bpm)
                rest_beats = float(self.rng.uniform(
                    0.20 + 0.35 * g.space,
                    0.55 + 2.8 * g.space
                ))
                self.rest_until_sample = trigger_sample + int(rest_beats * beat * SR)
                history.append(0)
                self.interval_memory.append(0)
                try:
                    self.event_queue.put_nowait(("breath", rest_beats))
                except Exception:
                    pass
                return False

        p = clamp(p, 0.03, 0.97)

        # Different loop lengths prevent the four clocks from becoming one
        # ordinary repeating sequencer.
        loop_len = (8, 6, 5, 7)[clock_index]
        can_remember = len(history) >= loop_len

        if can_remember:
            if self.rhythm_lock:
                memory_probability = 0.985
            else:
                memory_probability = g.memory * (0.26 + 0.66 * (1.0 - 0.55 * g.disorder))

            if self.rng.random() < memory_probability:
                emitted = bool(list(history)[-loop_len])

                # An unlocked memory can misremember: this is where a groove
                # quietly mutates rather than looping forever.
                if (not self.rhythm_lock):
                    slip = 0.015 + 0.19 * g.disorder * (1.0 - 0.65 * g.memory)
                    if self.rng.random() < slip:
                        emitted = not emitted
            else:
                emitted = self.rng.random() < p
        else:
            emitted = self.rng.random() < p

        history.append(1 if emitted else 0)
        self.interval_memory.append(1 if emitted else 0)
        return emitted

    def _choose_family(self, g):
        weights = np.asarray(g.family_bias, dtype=float).copy()

        # MEMORY gives recent choices a gravitational pull.
        if self.family_memory and self.rng.random() < 0.62 * g.memory:
            idx = self.family_memory[-1]
            weights[idx] *= 2.2 + 2.0 * g.memory

        # But avoid infinite monoculture.
        if len(self.family_memory) >= 3 and len(set(list(self.family_memory)[-3:])) == 1:
            weights[self.family_memory[-1]] *= 0.25

        weights /= weights.sum()
        idx = int(self.rng.choice(len(FAMILIES), p=weights))
        self.family_memory.append(idx)
        self.last_family = idx
        return idx

    def _callback(self, outdata, frames, time_info, status):
        if status:
            # Audio callbacks must not print continuously; signal GUI instead.
            try:
                self.event_queue.put_nowait(("status", str(status)))
            except Exception:
                pass

        block_start = self.sample_clock
        block_end = block_start + frames
        mix = np.zeros((frames, 2), dtype=np.float32)

        with self.lock:
            g = self.genome.copy()

            # Trigger all clock events falling inside this audio block.
            for c in range(4):
                guard = 0
                while self.next_triggers[c] < block_end and guard < 12:
                    t = int(self.next_triggers[c])
                    if t >= block_start and self._should_emit(c, g, t):
                        offset = t - block_start
                        voice = self._make_event(c, g)
                        if voice is not None:
                            self.voices.append(Voice(voice, pos=0, delay=max(0, offset)))
                            self.event_queue.put(("hit", c))
                    self._schedule_next(c, t, g)
                    guard += 1

            alive = []
            for v in self.voices:
                start = max(0, int(v.delay))
                if start >= frames:
                    v.delay -= frames
                    alive.append(v)
                    continue

                n = min(frames - start, len(v.audio) - v.pos)
                if n > 0:
                    mix[start:start+n] += v.audio[v.pos:v.pos+n]
                    v.pos += n
                v.delay = 0

                if v.pos < len(v.audio):
                    alive.append(v)
            self.voices = alive

            self.sample_clock += frames

        mix = softclip(mix * MASTER_HEADROOM).astype(np.float32, copy=False)
        outdata[:] = mix

        self.history.append(mix.copy())
        with self.scope_lock:
            if frames == BLOCK:
                self.scope = mix.copy()
            else:
                self.scope = np.resize(mix, (BLOCK, 2)).astype(np.float32)

    def _make_event(self, clock_index, g):
        # Seed fragments are an extra biological kingdom, not a replacement.
        seed_chance = 0.18 + 0.72 * g.fragment
        if self.timbre_lock:
            # Locking timbre keeps the source ecology steady rather than
            # allowing mutation pressure to throw it around.
            seed_chance = 0.18 + 0.64 * g.fragment

        use_seed = (
            self.seed_enabled
            and self.seed_fragments
            and self.rng.random() < seed_chance
        )
        if use_seed:
            return self._seed_voice(clock_index, g)

        family = self._choose_family(g)
        if family == 0:
            return self._pulse_voice(clock_index, g)
        if family == 1:
            return self._noise_voice(clock_index, g)
        if family == 2:
            return self._resonator_voice(clock_index, g)
        if family == 3:
            return self._fm_voice(clock_index, g)
        return self._particle_voice(clock_index, g)

    def _stereo(self, mono, pan):
        l, r = equal_power_pan(pan)
        out = np.empty((len(mono), 2), dtype=np.float32)
        out[:, 0] = mono * l
        out[:, 1] = mono * r
        return out

    def _event_pan(self, clock_index, g):
        anchors = (-0.55, 0.45, -0.20, 0.65)
        movement = self.rng.normal(0.0, 0.12 + 0.32 * g.mutation)
        return float(np.clip(anchors[clock_index] + movement, -0.95, 0.95))

    def _pulse_voice(self, c, g):
        dur = float(self.rng.uniform(0.045, 0.20))
        n = max(16, int(dur * SR))
        t = np.arange(n, dtype=np.float32) / SR

        base = [48.0, 78.0, 125.0, 190.0][c]
        base *= 0.72 + 1.4 * g.timbre
        base *= float(self.rng.uniform(0.78, 1.28))
        fall = base * (1.0 + 3.0 * self.rng.uniform(0.1, 0.9))
        freq = base + (fall - base) * np.exp(-t * (20.0 + 45.0 * g.timbre))
        phase = 2.0 * np.pi * np.cumsum(freq) / SR
        wave = np.sign(np.sin(phase)) * (0.28 + 0.72 * g.timbre) + np.sin(phase) * (0.72 - 0.55 * g.timbre)
        env = np.exp(-t * self.rng.uniform(18.0, 48.0))
        click = np.zeros(n, dtype=np.float32)
        click[: min(16, n)] = np.linspace(1.0, 0.0, min(16, n), dtype=np.float32)
        mono = (0.40 * wave * env + 0.15 * click).astype(np.float32)
        return self._stereo(mono, self._event_pan(c, g))

    def _noise_voice(self, c, g):
        dur = float(self.rng.uniform(0.025, 0.24))
        n = max(16, int(dur * SR))
        t = np.arange(n, dtype=np.float32) / SR
        x = self.rng.standard_normal(n).astype(np.float32)

        # Cheap "spectral shape" via differences and running average.
        if g.timbre > 0.5:
            x = np.concatenate(([x[0]], np.diff(x))).astype(np.float32)
        else:
            k = int(2 + (1.0 - g.timbre) * 18)
            kernel = np.ones(k, dtype=np.float32) / k
            x = np.convolve(x, kernel, mode="same").astype(np.float32)

        env = np.exp(-t * self.rng.uniform(12.0, 72.0))
        mono = (x * env * self.rng.uniform(0.16, 0.34)).astype(np.float32)
        return self._stereo(mono, self._event_pan(c, g))

    def _resonator_voice(self, c, g):
        dur = float(self.rng.uniform(0.10, 0.55))
        n = max(16, int(dur * SR))
        t = np.arange(n, dtype=np.float32) / SR

        root = [120.0, 180.0, 270.0, 410.0][c] * (0.65 + 1.35 * g.timbre)
        ratios = [1.0, 1.4142, 1.618, 2.03]
        mono = np.zeros(n, dtype=np.float32)
        for i, rr in enumerate(ratios[: 2 + int(g.timbre * 2.9)]):
            f = root * rr * float(self.rng.uniform(0.97, 1.03))
            decay = self.rng.uniform(4.0, 11.0) * (1.0 + 0.25 * i)
            mono += (np.sin(2 * np.pi * f * t + self.rng.uniform(0, 2*np.pi)) * np.exp(-t * decay)).astype(np.float32) / (1.5 + i)
        mono *= 0.24
        mono[: min(10, n)] += np.linspace(0.30, 0.0, min(10, n), dtype=np.float32)
        return self._stereo(mono, self._event_pan(c, g))

    def _fm_voice(self, c, g):
        dur = float(self.rng.uniform(0.035, 0.30))
        n = max(16, int(dur * SR))
        t = np.arange(n, dtype=np.float32) / SR

        carrier = [90.0, 160.0, 240.0, 360.0][c] * float(self.rng.uniform(0.8, 1.3))
        ratio = float(self.rng.choice([0.5, 0.75, 1.0, 1.5, 2.0, 2.414, 3.0]))
        mod = carrier * ratio
        index = 0.5 + 9.0 * g.timbre + self.rng.uniform(0.0, 4.0 * g.mutation)
        env = np.exp(-t * self.rng.uniform(10.0, 45.0))
        phase = 2*np.pi*carrier*t + index * env * np.sin(2*np.pi*mod*t)
        mono = (np.sin(phase) * env * 0.30).astype(np.float32)
        return self._stereo(mono, self._event_pan(c, g))

    def _particle_voice(self, c, g):
        dur = float(self.rng.uniform(0.08, 0.42))
        n = max(64, int(dur * SR))
        mono = np.zeros(n, dtype=np.float32)
        count = int(4 + 28 * g.timbre + self.rng.integers(0, 8))
        for _ in range(count):
            pos = int(self.rng.integers(0, max(1, n - 24)))
            ln = int(self.rng.integers(8, min(220, n - pos + 1)))
            if ln <= 1:
                continue
            tt = np.arange(ln, dtype=np.float32) / SR
            f = float(self.rng.uniform(700.0, 9000.0))
            grain = np.sin(2*np.pi*f*tt + self.rng.uniform(0, 2*np.pi))
            grain *= np.hanning(ln).astype(np.float32)
            grain *= float(self.rng.uniform(0.02, 0.09))
            mono[pos:pos+ln] += grain.astype(np.float32)
        return self._stereo(mono, self._event_pan(c, g))

    # ---------- seed ----------
    def load_seed(self, path):
        data, src_sr = sf.read(path, always_2d=True, dtype="float32")
        mono = data.mean(axis=1)
        if len(mono) < 64:
            raise ValueError("Seed file is too short.")
        mono = resample_linear(mono, src_sr, SR)
        peak = float(np.max(np.abs(mono)))
        if peak > 1e-8:
            mono = mono / peak

        # Lightweight transient-ish analysis:
        # smoothed absolute amplitude -> positive energy changes -> peaks.
        win = max(8, int(0.008 * SR))
        kernel = np.ones(win, dtype=np.float32) / win
        env = np.convolve(np.abs(mono), kernel, mode="same")
        flux = np.maximum(0.0, np.diff(env, prepend=env[0]))

        min_gap = int(0.055 * SR)
        threshold = float(np.percentile(flux, 88.0))
        candidates = np.where(flux >= threshold)[0].tolist()

        peaks = []
        last = -min_gap
        for idx in candidates:
            if idx - last >= min_gap:
                peaks.append(idx)
                last = idx

        if not peaks:
            peaks = np.linspace(0, max(0, len(mono)-1), 12, dtype=int).tolist()

        fragments = []
        for idx in peaks[:96]:
            dur = float(self.rng.uniform(0.045, 0.26))
            ln = max(64, int(dur * SR))
            start = max(0, idx - int(0.005 * SR))
            frag = mono[start:start+ln].copy()
            if len(frag) < 64:
                continue
            fade = min(int(0.008 * SR), len(frag)//4)
            if fade > 1:
                frag[:fade] *= np.linspace(0.0, 1.0, fade, dtype=np.float32)
                frag[-fade:] *= np.linspace(1.0, 0.0, fade, dtype=np.float32)
            fragments.append(frag.astype(np.float32))

        if not fragments:
            raise ValueError("Could not extract usable fragments from the seed.")

        with self.lock:
            self.seed_path = Path(path)
            self.seed_fragments = fragments
            self.seed_enabled = True

        return len(fragments)

    def toggle_seed(self):
        with self.lock:
            if not self.seed_fragments:
                self.seed_enabled = False
            else:
                self.seed_enabled = not self.seed_enabled
            return self.seed_enabled

    def _seed_voice(self, c, g):
        frag = self.seed_fragments[int(self.rng.integers(0, len(self.seed_fragments)))].copy()

        # Mutation changes playback rate, but does not modify the source file.
        semis = self.rng.normal(0.0, 1.5 + 7.0 * g.mutation)
        rate = float(2.0 ** (semis / 12.0))
        if abs(rate - 1.0) > 0.015:
            new_len = max(24, int(len(frag) / rate))
            old = np.linspace(0.0, 1.0, len(frag), endpoint=False)
            new = np.linspace(0.0, 1.0, new_len, endpoint=False)
            frag = np.interp(new, old, frag).astype(np.float32)

        if self.rng.random() < 0.16 + 0.52 * g.fragment:
            frag = frag[::-1].copy()

        if self.rng.random() < 0.10 + 0.35 * g.fragment and len(frag) > 96:
            # micro-loop/repetition
            ln = int(self.rng.integers(48, min(len(frag), int(0.045 * SR))))
            chunk = frag[:ln]
            reps = int(self.rng.integers(2, 7))
            frag = np.tile(chunk, reps).astype(np.float32)

        env = np.linspace(1.0, 0.0, len(frag), dtype=np.float32) ** (0.2 + 1.8 * g.timbre)
        mono = frag * env * 0.42
        return self._stereo(mono, self._event_pan(c, g))

    # ---------- save ----------
    def save_recent_audio(self, out_dir=None):
        blocks = list(self.history)
        if not blocks:
            raise RuntimeError("Nothing has been played yet.")

        audio = np.concatenate(blocks, axis=0)
        max_samples = int(HISTORY_SECONDS * SR)
        if len(audio) > max_samples:
            audio = audio[-max_samples:]

        if out_dir is None:
            out_dir = Path.home() / "Folio_Captures"
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = out_dir / f"Folio_{stamp}.wav"
        sf.write(path, audio, SR, subtype="PCM_24")
        return path, len(audio) / SR


class Knob(tk.Canvas):
    def __init__(
        self, master, label, minimum, maximum, value,
        command=None, formatter=None, size=92
    ):
        super().__init__(
            master, width=size, height=size+34,
            bg=PANEL, bd=0, highlightthickness=0
        )
        self.label = label
        self.minimum = float(minimum)
        self.maximum = float(maximum)
        self.value = float(value)
        self.command = command
        self.formatter = formatter or (lambda x: f"{x:.2f}")
        self.size = size
        self.last_y = None
        self.bind("<Button-1>", self._down)
        self.bind("<B1-Motion>", self._drag)
        self.bind("<MouseWheel>", self._wheel)
        self.bind("<Button-4>", lambda e: self._nudge(+1))
        self.bind("<Button-5>", lambda e: self._nudge(-1))
        self._draw()

    def _down(self, event):
        self.last_y = event.y

    def _drag(self, event):
        if self.last_y is None:
            self.last_y = event.y
        dy = self.last_y - event.y
        self.last_y = event.y
        span = self.maximum - self.minimum
        self.set(self.value + dy * span / 240.0, emit=True)

    def _wheel(self, event):
        self._nudge(1 if event.delta > 0 else -1)

    def _nudge(self, direction):
        span = self.maximum - self.minimum
        self.set(self.value + direction * span / 120.0, emit=True)

    def set(self, value, emit=False):
        self.value = max(self.minimum, min(self.maximum, float(value)))
        self._draw()
        if emit and self.command:
            self.command(self.value)

    def _draw(self):
        self.delete("all")
        cx = self.size / 2
        cy = self.size / 2 + 3
        r = self.size * 0.34

        self.create_oval(
            cx-r-5, cy-r-5, cx+r+5, cy+r+5,
            fill="#101010", outline=EDGE, width=2
        )
        self.create_oval(
            cx-r, cy-r, cx+r, cy+r,
            fill="#242424", outline="#484848", width=1
        )

        norm = (self.value - self.minimum) / (self.maximum - self.minimum)
        a0 = math.radians(225)
        a1 = math.radians(-45)
        # Tk coordinates have downward y; interpolate 270 degrees clockwise.
        angle = math.radians(225 - norm * 270)
        x2 = cx + math.cos(angle) * r * 0.75
        y2 = cy - math.sin(angle) * r * 0.75
        self.create_line(cx, cy, x2, y2, fill=HOT, width=3, capstyle=tk.ROUND)
        self.create_oval(cx-3, cy-3, cx+3, cy+3, fill=DARK, outline="")

        self.create_text(
            cx, self.size+5, text=self.label,
            fill=TEXT, font=("DejaVu Sans", 9, "bold")
        )
        self.create_text(
            cx, self.size+22, text=self.formatter(self.value),
            fill=MUTED, font=("DejaVu Sans Mono", 8)
        )


class FolioApp:
    def __init__(self, root):
        self.root = root
        self.engine = FolioEngine()
        self.knobs = {}
        self.flash = [0, 0, 0, 0]
        self.last_status = ""

        root.title(f"Folio {VERSION}")
        root.configure(bg=PANEL)
        root.resizable(False, False)
        try:
            root.attributes("-alpha", 0.995)
        except Exception:
            pass

        self._build()
        self._sync_knobs()
        self._animate()
        root.protocol("WM_DELETE_WINDOW", self.close)

    def _build(self):
        outer = tk.Frame(self.root, bg=PANEL, padx=18, pady=14)
        outer.pack()

        top = tk.Frame(outer, bg=PANEL)
        top.pack(fill="x")

        tk.Label(
            top, text="FOLIO", bg=PANEL, fg=TEXT,
            font=("DejaVu Sans", 22, "bold")
        ).pack(side="left")

        tk.Label(
            top, text="generative rhythm organism · v0.2", bg=PANEL, fg=MUTED,
            font=("DejaVu Sans", 9)
        ).pack(side="left", padx=(10, 0), pady=(9, 0))

        self.source_label = tk.Label(
            top, text="SOURCE · INTERNAL", bg=PANEL, fg=ACCENT,
            font=("DejaVu Sans Mono", 9, "bold")
        )
        self.source_label.pack(side="right", pady=(8, 0))

        mid = tk.Frame(outer, bg=PANEL)
        mid.pack(fill="x", pady=(10, 2))

        knob_specs = [
            ("density", "DENSITY", 0.0, 1.0),
            ("disorder", "DISORDER", 0.0, 1.0),
            ("memory", "MEMORY", 0.0, 1.0),
            ("space", "SPACE", 0.0, 1.0),
            ("mutation", "MUTATION", 0.0, 1.0),
            ("fragment", "FRAGMENT", 0.0, 1.0),
            ("timbre", "TIMBRE", 0.0, 1.0),
            ("bpm", "BPM", 45.0, 220.0),
        ]
        for name, label, lo, hi in knob_specs:
            fmt = (lambda x: f"{x:5.1f}") if name == "bpm" else (lambda x: f"{x:0.2f}")
            k = Knob(
                mid, label, lo, hi, getattr(self.engine.genome, name),
                command=lambda v, n=name: self.engine.set_param(n, v),
                formatter=fmt,
                size=78
            )
            k.pack(side="left", padx=2)
            self.knobs[name] = k

        visual = tk.Frame(outer, bg=PANEL_2, highlightbackground=EDGE, highlightthickness=1)
        visual.pack(fill="x", pady=(8, 10))

        self.scope_canvas = tk.Canvas(
            visual, width=704, height=106, bg=PANEL_2,
            bd=0, highlightthickness=0
        )
        self.scope_canvas.pack(side="left", padx=(8, 0), pady=8)

        self.organism_canvas = tk.Canvas(
            visual, width=120, height=106, bg=PANEL_2,
            bd=0, highlightthickness=0
        )
        self.organism_canvas.pack(side="right", padx=8, pady=8)

        controls = tk.Frame(outer, bg=PANEL)
        controls.pack(fill="x")

        self.start_btn = self._button(controls, "START", self.start, width=7)
        self.start_btn.pack(side="left", padx=(0, 4))

        self.stop_btn = self._button(controls, "STOP", self.stop, width=7)
        self.stop_btn.pack(side="left", padx=4)

        self._button(controls, "REGENERATE", self.regenerate, width=11).pack(side="left", padx=4)
        self._button(controls, "MUTATE", self.mutate, width=8).pack(side="left", padx=4)

        self.seed_btn = self._button(controls, "LOAD SEED", self.load_seed, width=9)
        self.seed_btn.pack(side="left", padx=4)

        self.source_btn = self._button(controls, "SOURCE", self.toggle_source, width=7)
        self.source_btn.pack(side="left", padx=4)

        save_btn = self._button(controls, "SAVE", self.save, width=7, accent=True)
        save_btn.pack(side="right", padx=(4, 0))

        protect = tk.Frame(outer, bg=PANEL)
        protect.pack(fill="x", pady=(6, 0))

        self.rhythm_lock_btn = self._button(
            protect, "RHYTHM · LOOSE", self.toggle_rhythm_lock, width=14
        )
        self.rhythm_lock_btn.pack(side="left", padx=(0, 4))

        self.timbre_lock_btn = self._button(
            protect, "TIMBRE · LOOSE", self.toggle_timbre_lock, width=14
        )
        self.timbre_lock_btn.pack(side="left", padx=4)

        self._button(protect, "STORE STATE", self.store_state, width=11).pack(side="left", padx=4)
        self._button(protect, "RECALL", self.recall_state, width=8).pack(side="left", padx=4)

        tk.Label(
            protect, text="v0.2 · memory / breath / selective protection",
            bg=PANEL, fg=MUTED, font=("DejaVu Sans Mono", 7)
        ).pack(side="right")

        self.status = tk.Label(
            outer,
            text="ready · SAVE captures the last 16 seconds exactly as heard",
            bg=PANEL, fg=MUTED, anchor="w",
            font=("DejaVu Sans Mono", 8)
        )
        self.status.pack(fill="x", pady=(8, 0))

    def _button(self, master, text, command, width=10, accent=False):
        return tk.Button(
            master,
            text=text,
            command=command,
            width=width,
            bg=("#3a3423" if accent else "#242424"),
            fg=(HOT if accent else TEXT),
            activebackground="#343434",
            activeforeground=HOT,
            relief="flat",
            bd=0,
            padx=6,
            pady=6,
            font=("DejaVu Sans", 8, "bold"),
            cursor="hand2"
        )

    def _sync_knobs(self):
        g = self.engine.snapshot()
        for name, knob in self.knobs.items():
            knob.set(getattr(g, name), emit=False)

    def set_status(self, text):
        self.last_status = text
        self.status.configure(text=text)

    def start(self):
        try:
            self.engine.start()
            self.set_status("running · four clocks are interacting")
            self.start_btn.configure(fg=HOT)
        except Exception as exc:
            messagebox.showerror("Folio — audio error", str(exc))
            self.set_status("audio start failed")

    def stop(self):
        self.engine.stop()
        self.set_status("stopped · recent audio remains available to SAVE")
        self.start_btn.configure(fg=TEXT)

    def regenerate(self):
        self.engine.regenerate()
        self._sync_knobs()
        protected = []
        if self.engine.rhythm_lock:
            protected.append("rhythm")
        if self.engine.timbre_lock:
            protected.append("timbre")
        if protected:
            self.set_status("regenerated · protected " + " + ".join(protected))
        else:
            self.set_status("new organism generated")

    def mutate(self):
        self.engine.mutate_genome()
        self._sync_knobs()
        locks = []
        if self.engine.rhythm_lock:
            locks.append("rhythm protected")
        if self.engine.timbre_lock:
            locks.append("timbre protected")
        suffix = (" · " + " / ".join(locks)) if locks else ""
        self.set_status("descendant organism created" + suffix)

    def toggle_rhythm_lock(self):
        locked = self.engine.toggle_rhythm_lock()
        self.rhythm_lock_btn.configure(
            text=("RHYTHM · LOCKED" if locked else "RHYTHM · LOOSE"),
            fg=(HOT if locked else TEXT),
            bg=("#3a3423" if locked else "#242424")
        )
        if locked:
            self.set_status("rhythm locked · remembered motifs stabilise")
        else:
            self.set_status("rhythm loose · motifs may drift again")

    def toggle_timbre_lock(self):
        locked = self.engine.toggle_timbre_lock()
        self.timbre_lock_btn.configure(
            text=("TIMBRE · LOCKED" if locked else "TIMBRE · LOOSE"),
            fg=(HOT if locked else TEXT),
            bg=("#3a3423" if locked else "#242424")
        )
        if locked:
            self.set_status("timbre locked · sound ecology protected")
        else:
            self.set_status("timbre loose · sound ecology may mutate")

    def _sync_lock_buttons(self):
        self.rhythm_lock_btn.configure(
            text=("RHYTHM · LOCKED" if self.engine.rhythm_lock else "RHYTHM · LOOSE"),
            fg=(HOT if self.engine.rhythm_lock else TEXT),
            bg=("#3a3423" if self.engine.rhythm_lock else "#242424")
        )
        self.timbre_lock_btn.configure(
            text=("TIMBRE · LOCKED" if self.engine.timbre_lock else "TIMBRE · LOOSE"),
            fg=(HOT if self.engine.timbre_lock else TEXT),
            bg=("#3a3423" if self.engine.timbre_lock else "#242424")
        )

    def store_state(self):
        try:
            path = self.engine.store_state()
            self.set_status(f"state stored · {path}")
        except Exception as exc:
            messagebox.showerror("Folio — STORE STATE", str(exc))

    def recall_state(self):
        initial = Path.home() / "Folio_States"
        path = filedialog.askopenfilename(
            title="Recall Folio state",
            initialdir=str(initial if initial.exists() else Path.home()),
            filetypes=[
                ("Folio state", "*.folio.json"),
                ("JSON", "*.json"),
                ("All files", "*.*")
            ]
        )
        if not path:
            return
        try:
            self.engine.recall_state(path)
            self._sync_knobs()
            self._sync_lock_buttons()
            self.set_status(f"state recalled · {Path(path).name}")
        except Exception as exc:
            messagebox.showerror("Folio — RECALL", str(exc))

    def load_seed(self):
        path = filedialog.askopenfilename(
            title="Load seed audio",
            filetypes=[
                ("Audio", "*.wav *.aiff *.aif *.flac *.ogg"),
                ("All files", "*.*")
            ]
        )
        if not path:
            return
        try:
            count = self.engine.load_seed(path)
            self.source_label.configure(text=f"SOURCE · SEED · {Path(path).name}")
            self.set_status(f"seed loaded · {count} fragments extracted")
        except Exception as exc:
            messagebox.showerror("Folio — seed error", str(exc))

    def toggle_source(self):
        enabled = self.engine.toggle_seed()
        if enabled and self.engine.seed_path:
            self.source_label.configure(text=f"SOURCE · SEED · {self.engine.seed_path.name}")
            self.set_status("seed fragments enabled")
        else:
            self.source_label.configure(text="SOURCE · INTERNAL")
            self.set_status("internal synthesis only")

    def save(self):
        try:
            path, seconds = self.engine.save_recent_audio()
            self.set_status(f"saved {seconds:0.1f}s exactly as heard · {path}")
        except Exception as exc:
            messagebox.showinfo("Folio — SAVE", str(exc))

    def _animate(self):
        # Drain event queue.
        while True:
            try:
                kind, payload = self.engine.event_queue.get_nowait()
            except Exception:
                break
            if kind == "hit":
                self.flash[int(payload) % 4] = 1.0
            elif kind == "status":
                self.set_status(f"audio: {payload}")
            elif kind == "breath":
                self.set_status(f"space · {float(payload):0.2f} beat rest")

        # Oscilloscope.
        with self.engine.scope_lock:
            scope = self.engine.scope.copy()

        self.scope_canvas.delete("all")
        w, h = 704, 106
        self.scope_canvas.create_line(0, h/2, w, h/2, fill="#292929")
        if len(scope):
            mono = scope.mean(axis=1)
            step = max(1, len(mono) // w)
            y = mono[::step][:w]
            points = []
            for i, val in enumerate(y):
                xx = i * (w / max(1, len(y)-1))
                yy = h/2 - float(val) * h * 0.43
                points.extend((xx, yy))
            if len(points) >= 4:
                self.scope_canvas.create_line(*points, fill=ACCENT, width=1)

        # Four-clock organism.
        self.organism_canvas.delete("all")
        cx, cy = 60, 53
        radii = (13, 23, 34, 45)
        for i, r in enumerate(radii):
            glow = clamp(self.flash[i])
            base = int(80 + glow * 160)
            col = f"#{base:02x}{int(base*0.88):02x}{int(base*0.50):02x}"
            self.organism_canvas.create_oval(
                cx-r, cy-r, cx+r, cy+r,
                outline=col, width=1 + int(glow * 2)
            )
            self.flash[i] *= 0.82
        self.organism_canvas.create_oval(cx-3, cy-3, cx+3, cy+3, fill=HOT, outline="")

        self.root.after(33, self._animate)

    def close(self):
        self.engine.stop()
        self.root.destroy()


def main():
    root = tk.Tk()
    FolioApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
